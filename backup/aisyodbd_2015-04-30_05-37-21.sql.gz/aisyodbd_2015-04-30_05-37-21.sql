#SXD20|20011|50542|50438|2015.04.30 05:37:21|aisyodbd|0|14|92|
#TA aboutchildren`9`632|admins`1`28|children`9`452|childtocon`4`84|contract`3`288|katlgot`9`608|periods`3`104|putevka`0`0|request_children`8`780|requests`8`920|requests_user`14`840|resttype`9`536|scholl`13`1172|whens`2`16384
#EOH

#	TC`aboutchildren`utf8_general_ci	;
CREATE TABLE `aboutchildren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `adr` varchar(255) DEFAULT NULL,
  `adrfact` varchar(255) DEFAULT NULL,
  `scholl` int(11) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `fioroditelya` varchar(255) DEFAULT NULL,
  `workstation` varchar(255) DEFAULT NULL,
  `katlgot` int(11) NOT NULL,
  `rabota` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`),
  UNIQUE KEY `unique_iduser` (`iduser`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`aboutchildren`utf8_general_ci	;
INSERT INTO `aboutchildren` VALUES 
(2,2,'ипа',\N,\N,0,\N,'Семененко Тамара','ооо',0,'','','888',''),
(9,9,'dasdasd',\N,\N,0,\N,'asdasd','',0,'','','',''),
(8,8,'I-ПН',\N,\N,0,\N,'Семененко Кристина Игоревна','ООО',0,'','','221111',''),
(7,7,'и и',\N,\N,0,\N,'Семененко Тамара','ООО',0,'','','223322',''),
(6,6,'I-ПН',\N,\N,0,\N,'Семененко Кристина Игоревна','ООО',0,'','','221111',''),
(10,10,'asdasd',\N,\N,0,\N,'asdasd','asdasdas',0,'','','dasdasasda',''),
(11,11,'asdasdasdasdasd',\N,\N,0,\N,'dasdasdasdasd','asdasdasdasdasdasasdasd',0,'','','asdasdasdasdasasda',''),
(12,12,'asdasdas',\N,\N,0,\N,'dasdasd','asdsadas',0,'','','asdsadas',''),
(13,13,'sadasdasd',\N,\N,0,\N,'sadasdas','dasdas',0,'','','dasdasd','')	;
#	TC`admins`utf8_general_ci	;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`admins`utf8_general_ci	;
INSERT INTO `admins` VALUES 
(1,'serdimoa','27051993')	;
#	TC`children`utf8_general_ci	;
CREATE TABLE `children` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `event` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`children`utf8_general_ci	;
INSERT INTO `children` VALUES 
(2,'Николай','Савченко','Николаевич',0,'2009-06-10'),
(9,'asdas','asdasd','dasdasd',0,'2015-03-02'),
(8,'Тамара','Семечненко','Иосифовна',0,'1999-08-19'),
(6,'Тамара','Семечненко','Иосифовна',0,'1999-08-19'),
(7,'Виктор','Аксёнов','Викторович',0,'2005-02-09'),
(10,'asdasdas','adasd','dasdasd',0,'2015-04-13'),
(11,'asdasdassadasdasd','asdsadasdasdasd','dasdasdasdasdasd',0,'2015-04-13'),
(12,'asdasd','asdasd','asdsa',0,'2015-04-14'),
(13,'sdasdasd','asdasda','asdsad',0,'2015-04-07')	;
#	TC`childtocon`utf8_general_ci	;
CREATE TABLE `childtocon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idchild` int(11) NOT NULL,
  `idkont` int(11) NOT NULL,
  `idsmena` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`),
  KEY `id` (`id`),
  KEY `idchild` (`idchild`),
  KEY `idchild_2` (`idchild`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`childtocon`utf8_general_ci	;
INSERT INTO `childtocon` VALUES 
(8,7,1,5,0),
(2,3,1,1,0),
(7,6,2,2,0),
(9,13,1,1,0)	;
#	TC`contract`utf8_general_ci	;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `put` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `date` date NOT NULL,
  `types` int(11) NOT NULL,
  `daysprice` int(255) NOT NULL,
  `whens` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`contract`utf8_general_ci	;
INSERT INTO `contract` VALUES 
(1,'ООО \"Хаджохская турбаза горная\"',60,1716000,22,'2015-02-17',8,1300,1),
(2,'ГУП СО \"Санаторий Курьи\"',100,3093000,21,'2015-02-11',6,1300,2),
(3,'Остров детства',30,519412,12,'2015-01-22',5,1300,1)	;
#	TC`katlgot`utf8_general_ci	;
CREATE TABLE `katlgot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`katlgot`utf8_general_ci	;
INSERT INTO `katlgot` VALUES 
(1,'Дети-сироты,дети,оставшихся без попечения родителей'),
(2,'Дети из многодетных семей'),
(3,'Дети из семей, потерявших кормильца'),
(4,'Дети-инвалиды'),
(5,'Дети из семей беженцев и вынужденных переселенцев'),
(6,'Дети из малообеспеченных семей'),
(7,'Дети, состоящих на учете в КДН'),
(8,'Детей ветеранов боевых действий'),
(9,'Дети КМНС')	;
#	TC`periods`utf8_general_ci	;
CREATE TABLE `periods` (
  `enddate` date NOT NULL,
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `idcontract` int(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `nerasp` int(255) NOT NULL,
  `startdate` date NOT NULL,
  `summ` int(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `periodsUnique` (`id`),
  UNIQUE KEY `index_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`periods`utf8_general_ci	;
INSERT INTO `periods` VALUES 
('2015-07-31',1,1,'1 смена',998,'2015-06-01',1000),
('2015-05-22',2,2,'1 smena',5553,'2015-04-29',100),
('2015-04-20',5,1,'122',0,'2015-04-12',1)	;
#	TC`putevka`utf8_general_ci	;
CREATE TABLE `putevka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `nameput` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`request_children`utf8_general_ci	;
CREATE TABLE `request_children` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fio` varchar(255) DEFAULT NULL,
  `otch` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `fiorod` varchar(255) DEFAULT NULL,
  `workstation` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `idrequests` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`request_children`utf8_general_ci	;
INSERT INTO `request_children` VALUES 
(4,'Виктор','Аксёнов','Викторович','2005-02-09','и и','Семененко Тамара','ООО','223322',4),
(11,'gffggh','h','ffgfgfcgcfg','2015-04-15','mm,m','mnmnnmnm','fgfggf','fggfvv',11),
(12,'asdasd','sadasd','asdsad','2015-04-07','asdasdasd','sdsadasd','asdasd','dasdasd',12),
(13,'adasd','asd','asdasd','2015-04-14','asdad','dasdasdsad','sdadas','asdassa',13),
(14,'dasdasd','asdas','sadasd','2015-04-07','asdasdas','adasdasd','asdasda','sdsada',14),
(15,'dasdasd','asdas','sadasd','2015-04-07','asdasdas','adasdasd','asdasda','sdsada',15),
(17,'dasdas','dasdas','asdasd','2015-04-07','asdasdas','asdasdasd','sadasdasd','asdasdsada',17),
(21,'asdasd','sadasd','sadasd','2015-04-29','asdasd','asdasd','asdsad','asdsad',21)	;
#	TC`requests`utf8_general_ci	;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `timeobj` varchar(255) DEFAULT NULL,
  `whens` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`requests`utf8_general_ci	;
INSERT INTO `requests` VALUES 
(4,1,'2015','2015-03-11',\N,'9',0,'2','2','0'),
(11,1,'2015','2015-04-13',\N,'0',0,'1','1 смена','0'),
(12,1,'2015','2015-04-13',\N,'0',0,'ООО \"Хаджохская турбаза горная\"','1 смена','0'),
(13,1,'2015','2015-04-14',\N,'0',0,'1','1 смена',\N),
(14,1,'2015','2015-04-14',\N,'0',0,'2','1 smena','Зимние каникулы'),
(15,1,'2015','2015-04-14',\N,'0',0,'2','1 smena','Зимние каникулы'),
(17,1,'2015','2015-04-15',\N,\N,0,'ООО \"Хаджохская турбаза горная\"','1 смена','Летние каникулы'),
(21,1,'2015','2015-04-16',\N,'Республика Адыгея',0,'ООО \"Хаджохская турбаза горная\"','1 смена','Летние каникулы')	;
#	TC`requests_user`utf8_general_ci	;
CREATE TABLE `requests_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `timeobj` varchar(255) DEFAULT NULL,
  `whens` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8	;
#	TD`requests_user`utf8_general_ci	;
INSERT INTO `requests_user` VALUES 
(1,1,'2015','2015-03-11',\N,'9',1,'2','1',''),
(2,1,'2015','2015-03-11',\N,'9',2,'2','1',''),
(3,1,'2015','2015-03-11',\N,'9',3,'2','1',''),
(4,1,'2015','2015-03-12',\N,'7',4,'2','1',''),
(5,1,'2015','2015-03-23',\N,'8',5,'2','2',''),
(6,1,'2015','2015-03-12',\N,'9',6,'2','1',''),
(7,1,'2015','2015-03-11',\N,'9',7,'2','2',''),
(8,1,'2015','2015-03-12',\N,'7',8,'2','1',''),
(9,1,'2015','2015-03-23',\N,'3',9,'2','0',''),
(10,1,'2015','2015-04-15',\N,'0',10,'0','1',''),
(11,1,'2015','2015-04-15',\N,'Свердловская область',11,'ГУП СО \"Санаторий Курьи\"','1 smena',''),
(12,1,'2015','2015-04-14',\N,'0',12,'ООО \"Хаджохская турбаза горная\"','1 смена','Летние каникулы'),
(13,1,'2015','2015-04-14',\N,'0',0,'2','1 smena','Зимние каникулы'),
(14,1,'2015','2015-04-15',\N,'Республика Адыгея',13,'ООО \"Хаджохская турбаза горная\"','1 смена','Летние каникулы')	;
#	TC`resttype`utf8_general_ci	;
CREATE TABLE `resttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`resttype`utf8_general_ci	;
INSERT INTO `resttype` VALUES 
(1,1,'Лагеря с дневным пребыванием детей'),
(2,1,'Лагеря труда и отдыха'),
(3,1,'Лагеря палаточного типа'),
(4,2,'Ханты-Мансийский автономный округ-Югра'),
(5,2,'Тюменская область\r\n'),
(6,2,'Свердловская область'),
(7,2,'Краснодарский край г.Анапа'),
(8,2,'Республика Адыгея'),
(9,2,'Республика Крым')	;
#	TC`scholl`utf8_general_ci	;
CREATE TABLE `scholl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`scholl`utf8_general_ci	;
INSERT INTO `scholl` VALUES 
(1,'Средняя общеобразовательная школа №1'),
(2,'Средняя общеобразовательная школа №2 им. А.И.Исаевой'),
(3,'Средняя общеобразовательная школа №3'),
(4,'Средняя общеобразовательная кадетская школа №4'),
(5,'Средняя общеобразовательная школа №5'),
(6,'Средняя общеобразовательная школа №6'),
(7,'Средняя общеобразовательная школа №7'),
(8,'Средняя общеобразовательная школа №8'),
(9,'Средняя общеобразовательная школа №9'),
(10,'Средняя общеобразовательная школа №10'),
(11,'Средняя общеобразовательная школа №13'),
(12,'Средняя общеобразовательная школа №14'),
(13,'КОУ, Нефтеюганская школа для обучения детей с ограниченными возможностями здоровья.')	;
#	TC`whens`utf8_general_ci	;
CREATE TABLE `whens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`whens`utf8_general_ci	;
INSERT INTO `whens` VALUES 
(1,'Летние каникулы'),
(2,'Зимние каникулы')	;
