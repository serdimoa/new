#SXD20|20011|50540|50435|2015.02.20 06:53:14|aisyodbd|0|11|45|
#TA aboutchildren`5`16384|admins`1`16384|children`5`16384|contract`2`16384|katlgot`9`16384|putevka`0`16384|request_children`0`16384|requests`0`16384|requests_user`1`16384|resttype`9`16384|scholl`13`16384
#EOH

#	TC`aboutchildren`utf8_general_ci	;
CREATE TABLE `aboutchildren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `adr` varchar(255) DEFAULT NULL,
  `adrfact` varchar(255) DEFAULT NULL,
  `scholl` int(11) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `fioroditelya` varchar(255) DEFAULT NULL,
  `workstation` varchar(255) DEFAULT NULL,
  `katlgot` int(11) NOT NULL,
  `rabota` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`),
  UNIQUE KEY `unique_iduser` (`iduser`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`aboutchildren`utf8_general_ci	;
INSERT INTO `aboutchildren` VALUES 
(1,1,'123213231321','Г нижневартовск ','Г сургут',6,'5','Незнаю','нету ',7,'11-12-12','123123','89519820284','cjsaijcs@gmail.com'),
(3,3,'123213231321','Г нижневартовск ','Г сургут',6,'5','Незнаю','нету ',7,'11-12-12','123123','89519820284','cjsaijcs@gmail.com'),
(8,8,'ljkjkl','ljkl','jkljkl',8,'ljkl','kjl','ljkl',3,'jlkjl','ljkljklj','jkl','jkl'),
(9,9,'ljkjkl','ljkl','jkljkl',0,'ljkl','kjl','ljkl',0,'jlkjl','ljkljklj','jkl','jkl'),
(12,12,'qweqeqqwe','','',1,'','m,m,m','l;l;l;',5,'','','jjkjjkjkjk','')	;
#	TC`admins`utf8_general_ci	;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`admins`utf8_general_ci	;
INSERT INTO `admins` VALUES 
(1,'serdimoa','27051993')	;
#	TC`children`utf8_general_ci	;
CREATE TABLE `children` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `event` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`children`utf8_general_ci	;
INSERT INTO `children` VALUES 
(1,'Ваня','Костин','Петрович',0,'2014-07-07'),
(3,'Ваня','Костин','Петрович',0,'2014-07-07'),
(8,'jkl','jkl','jkl',0,'2015-02-03'),
(9,'jkl','jkl','jkl',0,'0000-00-00'),
(12,'adsfasdas','qwee','qwqewqwe',0,'2015-02-25')	;
#	TC`contract`utf8_general_ci	;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `put` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`contract`utf8_general_ci	;
INSERT INTO `contract` VALUES 
(1,'OOO \"JOO1\"',252,10000,25,'2015-02-07'),
(2,'hjhj',7777,77,77878,'2015-02-17')	;
#	TC`katlgot`utf8_general_ci	;
CREATE TABLE `katlgot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`katlgot`utf8_general_ci	;
INSERT INTO `katlgot` VALUES 
(1,'Дети-сироты,дети,оставшихся без попечения родителей'),
(2,'Дети из многодетных семей'),
(3,'Дети из семей, потерявших кормильца'),
(4,'Дети-инвалиды'),
(5,'Дети из семей беженцев и вынужденных переселенцев'),
(6,'Дети из малообеспеченных семей'),
(7,'Дети, состоящих на учете в КДН'),
(8,'Детей ветеранов боевых действий'),
(9,'Дети КМНС')	;
#	TC`putevka`utf8_general_ci	;
CREATE TABLE `putevka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `nameput` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`request_children`utf8_general_ci	;
CREATE TABLE `request_children` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fio` varchar(255) DEFAULT NULL,
  `otch` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `fiorod` varchar(255) DEFAULT NULL,
  `workstation` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `idrequests` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`requests`utf8_general_ci	;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `timeobj` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`requests_user`utf8_general_ci	;
CREATE TABLE `requests_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `timeobj` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`requests_user`utf8_general_ci	;
INSERT INTO `requests_user` VALUES 
(1,2,'2015','2015-02-16',\N,2,12,1,0)	;
#	TC`resttype`utf8_general_ci	;
CREATE TABLE `resttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`resttype`utf8_general_ci	;
INSERT INTO `resttype` VALUES 
(1,1,'Лагеря с дневным пребыванием детей'),
(2,1,'Лагеря труда и отдыха'),
(4,1,'Лагеря палаточного типа'),
(5,2,'Ханты-Мансийский автономный округ-Югра'),
(6,2,'Тюменская область\r\n'),
(7,2,'Свердловская область'),
(8,2,'Краснодарский край г.Анапа'),
(9,2,'Республика Адыгея'),
(10,2,'Республика Болгария')	;
#	TC`scholl`utf8_general_ci	;
CREATE TABLE `scholl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`scholl`utf8_general_ci	;
INSERT INTO `scholl` VALUES 
(1,'Средняя общеобразовательная школа №1'),
(2,'Средняя общеобразовательная школа №2 им. А.И.Исаевой'),
(3,'Средняя общеобразовательная школа №3'),
(4,'Средняя общеобразовательная кадетская школа №4'),
(5,'Средняя общеобразовательная школа №5'),
(6,'Средняя общеобразовательная школа №6'),
(7,'Средняя общеобразовательная школа №7'),
(8,'Средняя общеобразовательная школа №8'),
(9,'Средняя общеобразовательная школа №9'),
(10,'Средняя общеобразовательная школа №10'),
(11,'Средняя общеобразовательная школа №13'),
(12,'Средняя общеобразовательная школа №14'),
(13,'КОУ, Нефтеюганская школа для обучения детей с ограниченными возможностями здоровья.')	;
