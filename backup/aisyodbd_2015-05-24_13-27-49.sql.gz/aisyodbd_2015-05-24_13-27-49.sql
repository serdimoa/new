#SXD20|20011|50542|50440|2015.05.24 13:27:49|aisyodbd|0|14|43|
#TA aboutchildren`0`0|admins`1`28|children`0`0|childtocon`0`0|contract`3`284|katlgot`10`632|periods`3`104|putevka`0`0|request_children`0`0|requests`0`0|requests_user`0`0|resttype`9`536|scholl`13`1172|whens`4`16384
#EOH

#	TC`aboutchildren`utf8_general_ci	;
CREATE TABLE `aboutchildren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `adr` varchar(255) DEFAULT NULL,
  `adrfact` varchar(255) DEFAULT NULL,
  `scholl` int(11) NOT NULL,
  `class` varchar(255) DEFAULT NULL,
  `fioroditelya` varchar(255) DEFAULT NULL,
  `workstation` varchar(255) DEFAULT NULL,
  `katlgot` int(11) NOT NULL,
  `rabota` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`),
  UNIQUE KEY `unique_iduser` (`iduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`admins`utf8_general_ci	;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`admins`utf8_general_ci	;
INSERT INTO `admins` VALUES 
(1,'serdimoa','27051993')	;
#	TC`children`utf8_general_ci	;
CREATE TABLE `children` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `event` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`childtocon`utf8_general_ci	;
CREATE TABLE `childtocon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idchild` int(11) NOT NULL,
  `idkont` int(11) NOT NULL,
  `idsmena` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`),
  KEY `id` (`id`),
  KEY `idchild` (`idchild`),
  KEY `idchild_2` (`idchild`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`contract`utf8_general_ci	;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `put` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `date` date NOT NULL,
  `types` int(11) NOT NULL,
  `daysprice` int(255) NOT NULL,
  `whens` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`contract`utf8_general_ci	;
INSERT INTO `contract` VALUES 
(1,'ООО \"Хаджохская турбаза горная\"',60,1716000,22,'2015-02-17',8,1300,2),
(2,'ГУП СО \"Санаторий Курьи\"',100,3093000,21,'2015-02-11',6,1300,2),
(3,'Остров детства',30,519412,12,'2015-01-22',5,1300,1)	;
#	TC`katlgot`utf8_general_ci	;
CREATE TABLE `katlgot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`katlgot`utf8_general_ci	;
INSERT INTO `katlgot` VALUES 
(1,'Дети-сироты,дети,оставшихся без попечения родителей'),
(2,'Дети из многодетных семей'),
(3,'Дети из семей, потерявших кормильца'),
(4,'Дети-инвалиды'),
(5,'Дети из семей беженцев и вынужденных переселенцев'),
(6,'Дети из малообеспеченных семей'),
(7,'Дети, состоящих на учете в КДН'),
(8,'Детей ветеранов боевых действий'),
(9,'Дети КМНС'),
(0,'Без льгот')	;
#	TC`periods`utf8_general_ci	;
CREATE TABLE `periods` (
  `enddate` date NOT NULL,
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `idcontract` int(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `nerasp` int(255) NOT NULL,
  `startdate` date NOT NULL,
  `summ` int(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `periodsUnique` (`id`),
  UNIQUE KEY `index_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`periods`utf8_general_ci	;
INSERT INTO `periods` VALUES 
('2015-07-31',1,1,'1 смена',997,'2015-06-01',1000),
('2015-05-22',2,2,'1 smena',5553,'2015-04-29',100),
('2015-04-20',5,1,'122',0,'2015-04-12',1)	;
#	TC`putevka`utf8_general_ci	;
CREATE TABLE `putevka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `nameput` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`request_children`utf8_general_ci	;
CREATE TABLE `request_children` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fio` varchar(255) DEFAULT NULL,
  `otch` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `fiorod` varchar(255) DEFAULT NULL,
  `workstation` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `idrequests` int(11) NOT NULL,
  `scholl` int(11) NOT NULL,
  `class` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`requests`utf8_general_ci	;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `timeobj` varchar(255) DEFAULT NULL,
  `whens` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`requests_user`utf8_general_ci	;
CREATE TABLE `requests_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT NULL,
  `year` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `timeobj` varchar(255) DEFAULT NULL,
  `whens` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`resttype`utf8_general_ci	;
CREATE TABLE `resttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`resttype`utf8_general_ci	;
INSERT INTO `resttype` VALUES 
(1,1,'Лагеря с дневным пребыванием детей'),
(2,1,'Лагеря труда и отдыха'),
(3,1,'Лагеря палаточного типа'),
(4,2,'Ханты-Мансийский автономный округ-Югра'),
(5,2,'Тюменская область\r\n'),
(6,2,'Свердловская область'),
(7,2,'Краснодарский край г.Анапа'),
(8,2,'Республика Адыгея'),
(9,2,'Республика Крым')	;
#	TC`scholl`utf8_general_ci	;
CREATE TABLE `scholl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`scholl`utf8_general_ci	;
INSERT INTO `scholl` VALUES 
(1,'Средняя общеобразовательная школа №1'),
(2,'Средняя общеобразовательная школа №2 им. А.И.Исаевой'),
(3,'Средняя общеобразовательная школа №3'),
(4,'Средняя общеобразовательная кадетская школа №4'),
(5,'Средняя общеобразовательная школа №5'),
(6,'Средняя общеобразовательная школа №6'),
(7,'Средняя общеобразовательная школа №7'),
(8,'Средняя общеобразовательная школа №8'),
(9,'Средняя общеобразовательная школа №9'),
(10,'Средняя общеобразовательная школа №10'),
(11,'Средняя общеобразовательная школа №13'),
(12,'Средняя общеобразовательная школа №14'),
(13,'КОУ, Нефтеюганская школа для обучения детей с ограниченными возможностями здоровья.')	;
#	TC`whens`utf8_general_ci	;
CREATE TABLE `whens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`whens`utf8_general_ci	;
INSERT INTO `whens` VALUES 
(1,'Летние каникулы'),
(2,'Зимние каникулы'),
(3,'Осенние каникулы'),
(4,'Весенние каникулы')	;
